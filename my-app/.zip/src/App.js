// Phosphorus is icon library where we can use different types of icons
import "./App.css";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Navbar } from "./components/navbar";
import { Shop } from "./pages/shop/shop";
import { Cart } from "./pages/cart/cart";

function App() {
  return (
    <shopContextProvider>
    <Router>
      <Navbar/>
      <Routes>
        <Route path='/' element={<Shop/>}/>
          <Route path='/Cart' element={<Cart/>} />
      </Routes>
    </Router>
    </shopContextProvider>
  );
}

export default App;
